package group.assignment.a1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

public class TargetDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target_detail);

        Intent intent = getIntent();
        int id = intent.getIntExtra("id", 1);

        MyDatabaseHelper myDatabaseHelper = new MyDatabaseHelper(this, "Target.db", null, MyDatabaseHelper.dbVersion);
        SQLiteDatabase sqLiteDatabase = myDatabaseHelper.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.query("target", null, "id = " + id, null, null, null, null);

        ImageView iv = findViewById(R.id.imageView);
        TextView tv = findViewById(R.id.textView2);

        cursor.moveToFirst();
        @SuppressLint("Range") int icon = cursor.getInt(cursor.getColumnIndex("icon"));
        @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
        @SuppressLint("Range") int day = cursor.getInt(cursor.getColumnIndex("day"));

        iv.setImageResource(icon);
        tv.setText(name + day);
        cursor.close();
    }
}