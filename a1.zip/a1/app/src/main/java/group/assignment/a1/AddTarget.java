package group.assignment.a1;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class AddTarget extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_target);

        MyDatabaseHelper myDb = new MyDatabaseHelper(this,"Target.db", null, 2);
        SQLiteDatabase sqlDb = myDb.getWritableDatabase();

        Button button1 = findViewById(R.id.button);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddTarget.this, AddTargetDetail.class);
                int icon = R.drawable.ic_baseline_sports_tennis_24;
                String name = "Exercise";
                intent.putExtra("iconRes", icon);
                intent.putExtra("name", name);
                startActivity(intent);
                finish();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddTarget.this, AddTargetDetail.class);
                int icon = R.drawable.ic_baseline_directions_run_24;
                String name = "Exercise";
                intent.putExtra("iconRes", icon);
                intent.putExtra("name", name);
                startActivity(intent);
                finish();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddTarget.this, AddTargetDetail.class);
                int icon = R.drawable.ic_baseline_food_bank_24;
                String name = "Exercise";
                intent.putExtra("iconRes", icon);
                intent.putExtra("name", name);
                startActivity(intent);
                finish();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddTarget.this, AddTargetDetail.class);
                int icon = R.drawable.ic_baseline_menu_book_24;
                String name = "Exercise";
                intent.putExtra("iconRes", icon);
                intent.putExtra("name", name);
                startActivity(intent);
                finish();
            }
        });

    }
}