package group.assignment.a1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Checkin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkin);

        // 找到按钮视图
        Button btCheckIn = findViewById(R.id.bt_check_in);
        Button btProgress = findViewById(R.id.bt_progress);
        Button btCalendar = findViewById(R.id.bt_calendar);
        Button btProfile = findViewById(R.id.bt_profile);

        // 为每个按钮添加点击事件

        btProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Checkin.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Checkin.this, Countdown.class);
                startActivity(intent);
            }
        });

        btProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Checkin.this, SecondActivity.class);
                startActivity(intent);
            }
        });
    }
}