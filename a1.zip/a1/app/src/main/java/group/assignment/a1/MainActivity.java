package group.assignment.a1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<TargetItem> targetItemArrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 找到按钮视图
        Button btCheckIn = findViewById(R.id.bt_check_in);
        Button btProgress = findViewById(R.id.bt_progress);
        Button btCalendar = findViewById(R.id.bt_calendar);
        Button btProfile = findViewById(R.id.bt_profile);
        Button btComplete = findViewById(R.id.bt_complete);
        Button btInProgress = findViewById(R.id.bt_inprogress);
        ImageButton btAddTarget = findViewById(R.id.bt_add);


        refreshData();

        btComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btComplete.setBackgroundColor(Color.BLACK);
                btInProgress.setBackgroundColor(Color.TRANSPARENT);
            }
        });

        btInProgress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btInProgress.setBackgroundColor(Color.BLACK);
                btComplete.setBackgroundColor(Color.TRANSPARENT);
            }
        });

        btCheckIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 创建一个 Intent 来启动目标 Activity
                Intent intent = new Intent(MainActivity.this, Checkin.class);
                startActivity(intent);
            }
        });

        btCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Countdown.class);
                startActivity(intent);
            }
        });

        btProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });

        btAddTarget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddTarget.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        refreshData();
    }

    private void refreshData() {
        targetItemArrayList.clear();
        TargetListAdapter tlA = new TargetListAdapter(MainActivity.this, targetItemArrayList);

        MyDatabaseHelper dbHelper = new MyDatabaseHelper(this, "Target.db", null, MyDatabaseHelper.dbVersion);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.query("target", null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") int icon = cursor.getInt(cursor.getColumnIndex("icon"));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex("name"));
                @SuppressLint("Range") int day = cursor.getInt(cursor.getColumnIndex("day"));
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                targetItemArrayList.add(new TargetItem(name, icon, day, id));
            } while (cursor.moveToNext());
        }
        cursor.close();

        tlA = new TargetListAdapter(MainActivity.this, targetItemArrayList);
        ListView lv = findViewById(R.id.list_view_target);
        lv.setAdapter(tlA);

    }
}
