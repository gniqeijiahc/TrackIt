package group.assignment.a1;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class AddTargetDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_target_detail);

        MyDatabaseHelper myDb = new MyDatabaseHelper(this,"Target.db", null, MyDatabaseHelper.dbVersion);
        SQLiteDatabase sqlDb = myDb.getWritableDatabase();

        Intent intent = getIntent();
        int icon = intent.getIntExtra("iconRes", 0);
        String name = intent.getStringExtra("name");
        ImageView imv = findViewById(R.id.targetIcon);
        imv.setImageResource(icon);
        EditText nameTarget = findViewById(R.id.TargetName);

        Button buttonCreateTarget = findViewById(R.id.buttonAddTarget);
        buttonCreateTarget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues cv = new ContentValues();
                cv.put("icon", icon);
                if(nameTarget.getText().toString().isEmpty()) {
                    cv.put("name", name);
                }
                cv.put("name", nameTarget.getText().toString());
                cv.put("day", 0);
                sqlDb.insert("target", null, cv);
                sqlDb.close();
                myDb.close();
                finish();
            }
        });
    }
}