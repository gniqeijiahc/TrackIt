package group.assignment.a1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class TargetListAdapter extends BaseAdapter {
    private Context context;
    private List<TargetItem> targetList;

    public TargetListAdapter(Context context, List<TargetItem> targetList) {
        this.context = context;
        this.targetList = targetList;
    }

    @Override
    public int getCount() {
        return targetList.size();
    }

    @Override
    public Object getItem(int position) {
        return targetList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_target_layout, parent, false);
        }

        TargetItem targetItem = targetList.get(position);

        ImageView iconImageView = convertView.findViewById(R.id.iconImageView);
        TextView nameTextView = convertView.findViewById(R.id.nameTextView);
        TextView dayTextView = convertView.findViewById(R.id.dayTextView);

        iconImageView.setImageResource(targetItem.getIconResource());
        nameTextView.setText(targetItem.getName());
        dayTextView.setText("Day " + targetItem.getDay());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, TargetDetail.class);
                intent.putExtra("id", targetItem.getTargetId());
                context.startActivity(intent);
            }
        });

        return convertView;
    }
}


class TargetItem {
    private String name;
    private int iconResource;
    private int day;
    private int id = 1;

    public TargetItem(String name, int iconResource, int day) {
        this.name = name;
        this.iconResource = iconResource;
        this.day = day;
    }

    public TargetItem(String name, int iconResource, int day, int id) {
        this.name = name;
        this.iconResource = iconResource;
        this.day = day;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getIconResource() {
        return iconResource;
    }

    public int getDay() {
        return day;
    }

    public void setTargetId(int id){
        this.id = id;
    }

    public int getTargetId(){
        return this.id;
    }
}
