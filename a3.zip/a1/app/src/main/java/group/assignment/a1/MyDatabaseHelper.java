package group.assignment.a1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.widget.Toast;


public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static int dbVersion = 2;

    public static final String CREATE_TARGET = "create table target " +
            "(id integer primary key autoincrement, " +
            "icon int, " +
            "name text, " +
            "day int)";

    public static final String CREATE_PHOTO = "create table dailyLogin(" +
            "        id integer primary key autoincrement," +
            "        path text," +
            "        description text" +
            ")";

    private Context mContext;

    public MyDatabaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TARGET);
        sqLiteDatabase.execSQL(CREATE_PHOTO);
        Toast.makeText(mContext, "Create success", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS target");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS daylyLogin");
        onCreate(sqLiteDatabase);
    }
}


//create table target(
//    id integer primary key auroincreament,
//    icon int,
//    name text,
//    day int
//)

//create table dailyLogin(
//        id integer primary key autoincrement,
//        path text,
//        description text
//)
